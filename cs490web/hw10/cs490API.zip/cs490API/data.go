package main

var currentId int

var students Students
var courses Courses
var coursestudents CourseStudents

// Initialize the data
func init() {
	students = Students{
		Student{
			Id:    1,
			Name:  "Tony",
			Level: "Senior",
		},
		Student{
			Id:    2,
			Name:  "Butters",
			Level: "Super Senior",
		},
		Student{
			Id:    3,
			Name:  "Bob",
			Level: "Freshman",
		},
	}

	courses = Courses{
		Course{
			CourseNum:   "CS108",
			Name:        "Into to Programming",
			Max_Courses: 20,
		},
		Course{
			CourseNum:   "CS490",
			Name:        "Web Design & Programming",
			Max_Courses: 20,
		},
	}

	coursestudents = CourseStudents{
		CourseStudent{
			Id:         1,
			CourseNum:  "CS490",
			Student_Id: 1,
		},
		CourseStudent{
			Id:         2,
			CourseNum:  "CS490",
			Student_Id: 2,
		},
		CourseStudent{
			Id:         3,
			CourseNum:  "CS490",
			Student_Id: 3,
		},
		CourseStudent{
			Id:         4,
			CourseNum:  "CS108",
			Student_Id: 3,
		},
	}
}

func DataFindStudent(id int) Student {
	for _, s := range students {
		if s.Id == id {
			return s
		}
	}
	// return empty Student if not found
	return Student{}
}

func DataFindCourse(coursenum string) Course {
	for _, c := range courses {
		if c.CourseNum == coursenum {
			return c
		}
	}
	// return empty Course if not found
	return Course{}
}
