package main

type Student struct {
	Id    int    `json:"id"`
	Name  string `json:"name"`
	Level string `json:"level"`
}

type Students []Student
