package main

import (
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"

	"github.com/gorilla/mux"
)

func Index(w http.ResponseWriter, r *http.Request) {
	fmt.Fprint(w, "Welcome!\n")
}

func AllStudents(w http.ResponseWriter, r *http.Request) {
	// Used to give back header information as json and with a Status OK 200
	w.Header().Set("Content-Type", "application/json; charset=UTF-8")
	w.WriteHeader(http.StatusOK)
	// Simply returns all students
	if err := json.NewEncoder(w).Encode(students); err != nil {
		panic(err)
	}
}

func StudentsInCourse(w http.ResponseWriter, r *http.Request) {
	// This is how you get the variables from the Request
	// Gives back a map
	// More definition can found routes.go file
	vars := mux.Vars(r)
	// Use key coursenum to find value
	coursenum := vars["coursenum"]

	// Loop through all the coursestudents struct array
	for _, coursestudent := range coursestudents {
		// Compares to try and match the coursenum
		// This is not case sensative
		if strings.EqualFold(coursestudent.CourseNum, coursenum) {
			// Uses a function to find the student
			// More about the function can be found in the data.go file
			student := DataFindStudent(coursestudent.Student_Id)
			w.Header().Set("Content-Type", "application/json; charset=UTF-8")
			w.WriteHeader(http.StatusOK)
			if err := json.NewEncoder(w).Encode(student); err != nil {
				panic(err)
			}
		}
	}
}

func AllCourses(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json; charset=UTF-8")
	w.WriteHeader(http.StatusOK)
	// Simply returns all courses
	if err := json.NewEncoder(w).Encode(courses); err != nil {
		panic(err)
	}
}

func CoursesForStudent(w http.ResponseWriter, r *http.Request) {
	vars := mux.Vars(r)
	student_id := vars["student_id"]
	// Must convert string to int to compare
	id, err := strconv.Atoi(student_id)
	if err != nil {
		panic(err)
	}

	// Loop through coursestudents struct array
	for _, coursestudent := range coursestudents {
		// If it find a match on the student id it will print out the course
		if coursestudent.Student_Id == id {
			// Used to find the course based on the coursenum
			// More about the function can be found in data.go file
			course := DataFindCourse(coursestudent.CourseNum)
			w.Header().Set("Content-Type", "application/json; charset=UTF-8")
			w.WriteHeader(http.StatusOK)
			if err := json.NewEncoder(w).Encode(course); err != nil {
				panic(err)
			}
		}
	}
}
