package main

type Course struct {
	CourseNum   string `json:"coursenum"`
	Name        string `json:"name"`
	Max_Courses int    `json:"max_students"`
}

type Courses []Course
