package main

type CourseStudent struct {
	Id         int    `json:"id"`
	CourseNum  string `json:"coursenum"`
	Student_Id int    `json:"student_id"`
}

type CourseStudents []CourseStudent
